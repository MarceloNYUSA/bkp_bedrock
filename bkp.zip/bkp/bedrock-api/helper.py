import os, json
import boto3
from langchain.embeddings import BedrockEmbeddings
from langchain.document_loaders import PyPDFLoader
from langchain.indexes import VectorstoreIndexCreator
from langchain.vectorstores import FAISS

from langchain.memory import ConversationBufferMemory
from langchain.chains import ConversationalRetrievalChain
from langchain.llms.bedrock import Bedrock
from dotenv import load_dotenv
from langchain.prompts import PromptTemplate
from pydantic import BaseModel
from botocore.config import Config
from langchain.callbacks.streaming_stdout import StreamingStdOutCallbackHandler
from langchain.document_loaders import S3FileLoader

load_dotenv()

models_data = {"claude": "anthropic.claude-v2", "titan": "amazon.titan-text-lite-v1"}
model_name = models_data.get(os.getenv("model"), 'anthropic.claude-v2')
# DOCUMENT_TABLE = os.environ["DOCUMENT_TABLE"]
BUCKET = os.getenv("BUCKET")


s3 = boto3.client("s3")
# ddb = boto3.resource("dynamodb")
# document_table = ddb.Table(DOCUMENT_TABLE)
# logger = Logger()


# def set_doc_status(user_id, document_id, status):
#     document_table.update_item(
#         Key={"userid": user_id, "documentid": document_id},
#         UpdateExpression="SET docstatus = :docstatus",
#         ExpressionAttributeValues={":docstatus": status},
#     )

class Item(BaseModel):
    prompt: str
    model: str


def create_index(key, index):
    try:
        # event_body = json.loads(event["Records"][0]["body"])
        # document_id = event_body["documentid"]
        # user_id = event_body["user"]
        # key = event_body["key"]

        file_name_full = key.split("/")[-1]

        # set_doc_status(user_id, document_id, "PROCESSING")
        # download_path = f"/tmp/{file_name_full}"
        download_path = os.path.join(os.path.split(os.getcwd())[0], file_name_full)
        s3.download_file(BUCKET, key, download_path)

        #loader = PyPDFLoader(f"/tmp/{file_name_full}")
        loader = PyPDFLoader(download_path)

        # download_path2 = os.path.join(os.path.split(os.getcwd())[0], '4mbtest.pdf')
        # loader2 = PyPDFLoader(download_path2)
        # loaders = [loader, loader2]

        bedrock_runtime = boto3.client(
            service_name="bedrock-runtime",
            region_name="us-east-1",
        )

        embeddings = BedrockEmbeddings(
            model_id="amazon.titan-embed-text-v1",
            client=bedrock_runtime,
            region_name="us-east-1",
        )
        index_creator = VectorstoreIndexCreator(
            vectorstore_cls=FAISS,
            embedding=embeddings,
        )
        # index_from_loader = index_creator.from_loaders([loader, loader2])
        index_from_loader = index_creator.from_loaders([loader])

        # index_from_loader.vectorstore.save_local("/tmp")
        #
        # s3.upload_file(
        #     "/tmp/index.faiss", BUCKET, f"{file_name_full}/index.faiss"
        # )
        # s3.upload_file("/tmp/index.pkl", BUCKET, f"{file_name_full}/index.pkl")

        # from langchain.schema import Document
        #
        # list_of_documents = [
        #     Document(page_content=loader, metadata=dict(page=1)),
        #     Document(page_content=loader2, metadata=dict(page=2)),
        # ]
        # db = FAISS.from_documents(list_of_documents, embeddings)

        index_from_loader.vectorstore.save_local(os.path.split(os.getcwd())[0])

        s3.upload_file(
            f"{os.path.split(os.getcwd())[0]}/index.faiss", BUCKET, f"indexes/{index}/index.faiss"
        )
        s3.upload_file(f"{os.path.split(os.getcwd())[0]}/index.pkl", BUCKET, f"indexes/{index}/index.pkl")

        # set_doc_status(user_id, document_id, "READY")
        return True, "success"
    except Exception as e:
        print("Exception while create a index is :", str(e))
        return False, str(e)

# def get_index_data(user, input_question, index_name):
#     # s3.download_file(BUCKET, f"{file_name}/index.faiss", "/tmp/index.faiss")
#     # s3.download_file(BUCKET, f"{file_name}/index.pkl", "/tmp/index.pkl")
#     s3.download_file(BUCKET, f"indexes/{index_name}/index.faiss", f"{os.path.split(os.getcwd())[0]}/index.faiss")
#     s3.download_file(BUCKET, f"indexes/{index_name}/index.pkl", f"{os.path.split(os.getcwd())[0]}/index.pkl")

#     bedrock_runtime = boto3.client(
#         service_name="bedrock-runtime",
#         region_name="us-east-1",
#     )
#     embeddings, llm = BedrockEmbeddings(
#         model_id="amazon.titan-embed-text-v1",
#         client=bedrock_runtime,
#         region_name="us-east-1",
#     ), Bedrock(
#         model_id=model_name, client=bedrock_runtime, region_name="us-east-1"
#     )
#     #faiss_index = FAISS.load_local("/tmp", embeddings)
#     faiss_index = FAISS.load_local(os.path.split(os.getcwd())[0], embeddings)

#     # message_history = DynamoDBChatMessageHistory(
#     #     table_name=MEMORY_TABLE, session_id=conversation_id
#     # )

#     memory = ConversationBufferMemory(
#         memory_key="chat_history",
#         # chat_memory=message_history,
#         input_key="question",
#         output_key="answer",
#         return_messages=True,
#     )

#     if index_name == "MI":
#         prompt_template = """
#             Get the exact application name related to our question. If not find any answer return 'No data available'
#             <text>{context}</text>
#             <question>{question}</question>
#             """
#         prompt = PromptTemplate(template=prompt_template, input_variables=['context', 'question'])

#         qa = ConversationalRetrievalChain.from_llm(
#             llm=llm,
#             retriever=faiss_index.as_retriever(),
#             memory=memory,
#             return_source_documents=True,
#             combine_docs_chain_kwargs={"prompt": prompt}
#         )
#     else:
#         qa = ConversationalRetrievalChain.from_llm(
#             llm=llm,
#             retriever=faiss_index.as_retriever(),
#             memory=memory,
#             return_source_documents=True,
#         )

#     res = qa({"question": input_question})
#     print(res)
#     sources = {sr.metadata['source'] for sr in res['source_documents']}

#     return {
#         "Answer": str(res["answer"]),
#         "Sources": list(sources)
#     }

def get_index_data(user, input_question, index_name):
    try:
        # s3.download_file(BUCKET, f"{file_name}/index.faiss", "/tmp/index.faiss")
        # s3.download_file(BUCKET, f"{file_name}/index.pkl", "/tmp/index.pkl")
        s3.download_file(BUCKET, f"indexes/{index_name}/index.faiss", f"{os.path.split(os.getcwd())[0]}/index.faiss")
        s3.download_file(BUCKET, f"indexes/{index_name}/index.pkl", f"{os.path.split(os.getcwd())[0]}/index.pkl")

        bedrock_runtime = boto3.client(
            service_name="bedrock-runtime",
            region_name="us-east-1",
        )
        print(model_name)
        embeddings, llm = BedrockEmbeddings(
            model_id="amazon.titan-embed-text-v1",
            client=bedrock_runtime,
            region_name="us-east-1",
        ), Bedrock(
            model_id=model_name, client=bedrock_runtime, region_name="us-east-1"
        )
        #faiss_index = FAISS.load_local("/tmp", embeddings)
        faiss_index = FAISS.load_local(os.path.split(os.getcwd())[0], embeddings)

        # message_history = DynamoDBChatMessageHistory(
        #     table_name=MEMORY_TABLE, session_id=conversation_id
        # )

        memory = ConversationBufferMemory(
            memory_key="chat_history",
            # chat_memory=message_history,
            input_key="question",
            output_key="answer",
            return_messages=True,
        )

        if index_name == "MI":
            prompt_template = """
                Get the exact application name related to our question. If not find any answer return 'No data available'
                <text>{context}</text>
                <question>{question}</question>
                """
            prompt = PromptTemplate(template=prompt_template, input_variables=['context', 'question'])

            qa = ConversationalRetrievalChain.from_llm(
                llm=llm,
                retriever=faiss_index.as_retriever(),
                memory=memory,
                return_source_documents=True,
                combine_docs_chain_kwargs={"prompt": prompt}
            )
        else:
            qa = ConversationalRetrievalChain.from_llm(
                llm=llm,
                retriever=faiss_index.as_retriever(),
                memory=memory,
                return_source_documents=True,
            )

        res = qa({"question": input_question})
        print(res)
        sources = {sr.metadata['source'] for sr in res['source_documents']}

        return {
            "Answer": str(res["answer"]),
            "Sources": list(sources)
        }
    except Exception as e:
        return str(e)


def generate_data(model_id, prompts, input_model_name):
    try:
        config = Config(
            read_timeout=300,
            retries=dict(
                max_attempts=5
            )
        )
        print("Making a connection to bedrock-runtime")
        bedrock_runtime = boto3.client(service_name='bedrock-runtime', region_name='us-east-1', config=config)
        print("Connection success for bedrock-runtime")
        if input_model_name == 'titan':
            parameters = {
                "maxTokenCount": 1024,
                "stopSequences": [],
                "temperature": 0,
                "topP": 0.9
            }
            body = json.dumps({"inputText": prompts, "textGenerationConfig": parameters})
            accept = "application/json"
            contentType = "application/json"
            response = bedrock_runtime.invoke_model(
                body=body, modelId=model_id, accept=accept, contentType=contentType
            )
            response_body = json.loads(response.get("body").read())
            response = response_body.get("results")[0].get("outputText")
        else:
            inference_modifier = {
                'max_tokens_to_sample': 500,
                "temperature": 0.1,
                "top_k": 250,
                "top_p": 1,
            }
            # inference_modifier = {
            #     "maxTokenCount": 512,
            #     "stopSequences": [],
            #     "temperature": 0,
            #     "topP": 0.9
            # }
            print(model_id)
            # create the Langchain Bedrock Client
            llm = Bedrock(model_id=model_id, client=bedrock_runtime, model_kwargs=inference_modifier,
                          streaming=True,  # Toggle this to turn streaming on or off
                          callbacks=[StreamingStdOutCallbackHandler()])

            response = llm(prompts)
    except Exception as e:
        print("Exception while connecting the bedrock server is :", str(e))
        response = str(e)
    return response


def v1_create_index(index, bucket_prefix=''):
    try:
        s3 = boto3.client('s3')
        response = s3.list_objects_v2(Bucket=BUCKET, Prefix=bucket_prefix)
        if 'Contents' in response:
            files = [obj['Key'] for obj in response['Contents']]

        # s3 = boto3.resource('s3')
        # files = []
        # for obj in s3.Bucket(name=BUCKET).objects.filter(Prefix=bucket_prefix):
        #     files.append(obj.key)
        loaders = []
        for file in files:
            loader = S3FileLoader(BUCKET, file)
            loaders.append(loader)
        bedrock_runtime = boto3.client(
            service_name="bedrock-runtime",
            region_name="us-east-1",
        )

        embeddings = BedrockEmbeddings(
            model_id="amazon.titan-embed-text-v1",
            client=bedrock_runtime,
            region_name="us-east-1",
        )
        index_creator = VectorstoreIndexCreator(
            vectorstore_cls=FAISS,
            embedding=embeddings,
        )
        index_from_loader = index_creator.from_loaders(loaders)
        index_from_loader.vectorstore.save_local(os.path.split(os.getcwd())[0])
        s3.upload_file(
            f"{os.path.split(os.getcwd())[0]}/index.faiss", BUCKET, f"indexes/{index}/index.faiss"
        )
        s3.upload_file(f"{os.path.split(os.getcwd())[0]}/index.pkl", BUCKET, f"indexes/{index}/index.pkl")

        return True, 'success'
    except Exception as e:
        return False, str(e)
