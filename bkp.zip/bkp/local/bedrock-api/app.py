import uvicorn
from fastapi import FastAPI
from typing import Union
from helper import create_index, get_index_data, generate_data, v1_create_index
from fastapi.responses import PlainTextResponse
from helper import Item
from a2wsgi import ASGIMiddleware
from fastapi.middleware.cors import CORSMiddleware

origins = [
    "*"
]

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/")
async def hello_world():
    return "<p>Vera Framework - Bedrock API</p>"


@app.get("/test")
async def test():
    return "<p>Vera Framework - Bedrock API Test</p>"


@app.get("/create_index")
async def create_upload_index(key: str, index: Union[str, None] = None):
    resp = create_index(key, index)
    print(resp)
    return {"status": "success"}


@app.get('/get_data')
async def get_index(question: str, app_name: str, user: Union[str, None] = None):
    return get_index_data(user, question, index_name=app_name)


@app.post('/generate')
def get_data(item: Item):
    print("Generate response function started")
    models_data = {"claude": "anthropic.claude-v2", "titan": "amazon.titan-text-lite-v1"}

    prompts = item.prompt
    model_id = models_data.get(item.model)
    if not model_id:
        print("Using default model")
        model_id = "anthropic.claude-v2"

    resp = generate_data(model_id, prompts, item.model)
    return PlainTextResponse(resp)


@app.get("/v1/create_index")
async def v1_create_upload_index(prefix: str, index: Union[str, None] = None):
    status, resp = v1_create_index(index, prefix)
    print(resp)
    if status:
        return {"status": "success"}
    else:
        return resp

wsgi_app = ASGIMiddleware(app)

if __name__ == '__main__':
    uvicorn.run(app, port=8004)
